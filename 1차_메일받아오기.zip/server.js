require("dotenv").config();
const express = require("express");
const cors = require("cors");
const Imap = require("imap");
const { simpleParser } = require("mailparser");
const rateLimit = require("express-rate-limit");

const app = express();

// CORS 설정
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(",")
  : ["http://localhost:3000"];

app.use(
  cors({
    origin: allowedOrigins,
    credentials: true,
  })
);

app.use(express.json());
app.use(express.static("public"));

// Rate Limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15분
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // 최대 100 요청
});

app.use("/api/", limiter);

// 이메일 헤더 디코딩 함수
function decodeHeader(header) {
  if (!header) return "";

  const decoded = header.replace(
    /=\?([^?]+)\?([BQ])\?([^?]+)\?=/gi,
    (match, charset, encoding, text) => {
      try {
        if (encoding.toLowerCase() === "b") {
          return Buffer.from(text, "base64").toString("utf8");
        } else if (encoding.toLowerCase() === "q") {
          text = text.replace(/_/g, " ");
          return text.replace(/=([0-9A-F]{2})/gi, (match, hex) => {
            return String.fromCharCode(parseInt(hex, 16));
          });
        }
      } catch (e) {
        return match;
      }
      return match;
    }
  );

  return decoded;
}

// IMAP으로 이메일 가져오기
function fetchEmails(email, password, limit = 10) {
  return new Promise((resolve, reject) => {
    const imap = new Imap({
      user: email,
      password: password,
      host: "imap.naver.com",
      port: 993,
      tls: true,
      tlsOptions: { rejectUnauthorized: false },
    });

    const emails = [];

    imap.once("ready", () => {
      imap.openBox("INBOX", true, (err, box) => {
        if (err) {
          reject(err);
          return;
        }

        const totalMessages = box.messages.total;
        const start = Math.max(1, totalMessages - limit + 1);
        const end = totalMessages;

        if (totalMessages === 0) {
          imap.end();
          resolve([]);
          return;
        }

        const fetchRange = `${start}:${end}`;
        const f = imap.seq.fetch(fetchRange, {
          bodies: ["HEADER.FIELDS (FROM TO SUBJECT DATE)", "TEXT"],
          struct: true,
        });

        f.on("message", (msg, seqno) => {
          const emailData = {
            seqno: seqno,
            from: "",
            subject: "",
            date: "",
            body: "",
          };

          msg.on("body", (stream, info) => {
            let buffer = "";
            stream.on("data", (chunk) => {
              buffer += chunk.toString("utf8");
            });
            stream.once("end", () => {
              if (info.which === "TEXT") {
                simpleParser(buffer)
                  .then((parsed) => {
                    emailData.body = (
                      parsed.text ||
                      parsed.html ||
                      "본문 없음"
                    ).substring(0, 500);
                  })
                  .catch(() => {
                    emailData.body = buffer.substring(0, 500);
                  });
              } else {
                const lines = buffer.split("\r\n");
                lines.forEach((line) => {
                  const colonIndex = line.indexOf(":");
                  if (colonIndex > 0) {
                    const key = line.substring(0, colonIndex).toLowerCase();
                    const value = line.substring(colonIndex + 1).trim();

                    if (key === "from") {
                      emailData.from = decodeHeader(value);
                    } else if (key === "subject") {
                      emailData.subject = decodeHeader(value);
                    } else if (key === "date") {
                      emailData.date = value;
                    }
                  }
                });
              }
            });
          });

          msg.once("end", () => {
            emails.push(emailData);
          });
        });

        f.once("error", (err) => {
          reject(err);
        });

        f.once("end", () => {
          imap.end();
        });
      });
    });

    imap.once("error", (err) => {
      reject(err);
    });

    imap.once("end", () => {
      emails.sort((a, b) => b.seqno - a.seqno);
      resolve(emails);
    });

    imap.connect();
  });
}

// API 엔드포인트
app.post("/api/fetch-emails", async (req, res) => {
  try {
    const { email, password, limit } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: "이메일과 비밀번호를 입력해주세요.",
      });
    }

    const emails = await fetchEmails(email, password, parseInt(limit) || 10);

    res.json({
      success: true,
      emails: emails,
      count: emails.length,
    });
  } catch (error) {
    console.error("Error:", error);

    let errorMessage = "메일을 가져오는데 실패했습니다.";

    if (error.message.includes("Invalid credentials")) {
      errorMessage =
        "로그인 실패: 이메일 또는 비밀번호가 올바르지 않습니다. IMAP 설정이 활성화되어 있는지 확인해주세요.";
    } else if (
      error.message.includes("ENOTFOUND") ||
      error.message.includes("ETIMEDOUT")
    ) {
      errorMessage =
        "네트워크 연결 오류: 네이버 메일 서버에 연결할 수 없습니다.";
    }

    res.status(500).json({
      error: errorMessage,
      details:
        process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
});

// 헬스 체크 엔드포인트
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || "development",
  });
});

// 메인 페이지
app.get("/", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>네이버 메일 뷰어</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Apple SD Gothic Neo', 'Noto Sans KR', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        
        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            margin-bottom: 30px;
        }
        
        .notice {
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .notice strong {
            color: #856404;
        }
        
        .input-group {
            margin-bottom: 20px;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }
        
        .input-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        button:hover:not(:disabled) {
            transform: translateY(-2px);
        }
        
        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: none;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .email-list {
            display: none;
        }
        
        .email-count {
            font-size: 1.5em;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #667eea;
        }
        
        .email-item {
            border-bottom: 1px solid #e0e0e0;
            padding: 20px 0;
            transition: background 0.2s;
        }
        
        .email-item:hover {
            background: #f8f9fa;
            margin: 0 -10px;
            padding: 20px 10px;
            border-radius: 8px;
        }
        
        .email-item:last-child {
            border-bottom: none;
        }
        
        .email-from {
            color: #667eea;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 0.95em;
        }
        
        .email-subject {
            font-size: 1.2em;
            color: #333;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        .email-date {
            color: #999;
            font-size: 0.9em;
            margin-bottom: 12px;
        }
        
        .email-body {
            color: #666;
            line-height: 1.6;
            white-space: pre-wrap;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            font-size: 0.95em;
        }
        
        .loading {
            text-align: center;
            padding: 40px 20px;
            display: none;
        }
        
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📧 네이버 메일 뷰어</h1>
            <p>Node.js + IMAP으로 네이버 메일 확인하기</p>
        </div>
        
        <div class="card">
            <div class="notice">
                <strong>⚠️ 사용 전 필수 설정</strong><br>
                네이버 메일 → 환경설정 → POP3/IMAP 설정 → <strong>IMAP/SMTP 사용</strong>으로 변경해주세요.
            </div>
            
            <div class="alert alert-error" id="errorAlert"></div>
            
            <form id="emailForm" onsubmit="fetchEmails(event)">
                <div class="input-group">
                    <label for="email">네이버 이메일</label>
                    <input type="email" id="email" placeholder="example@naver.com" required>
                </div>
                
                <div class="input-group">
                    <label for="password">비밀번호</label>
                    <input type="password" id="password" placeholder="비밀번호 입력" required>
                </div>
                
                <div class="input-group">
                    <label for="limit">가져올 메일 개수</label>
                    <input type="number" id="limit" value="10" min="1" max="50">
                </div>
                
                <button type="submit" id="submitBtn">메일 가져오기</button>
            </form>
        </div>
        
        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p style="color: white; font-size: 1.2em;">메일을 가져오는 중...</p>
        </div>
        
        <div class="card email-list" id="emailList"></div>
    </div>
    
    <script>
        async function fetchEmails(event) {
            event.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const limit = document.getElementById('limit').value;
            
            const errorAlert = document.getElementById('errorAlert');
            const loading = document.getElementById('loading');
            const emailList = document.getElementById('emailList');
            const submitBtn = document.getElementById('submitBtn');
            
            errorAlert.style.display = 'none';
            emailList.style.display = 'none';
            loading.style.display = 'block';
            submitBtn.disabled = true;
            
            try {
                const response = await fetch('/api/fetch-emails', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email, password, limit: parseInt(limit) })
                });
                
                const data = await response.json();
                
                if (!response.ok) {
                    throw new Error(data.error || '메일을 가져오는데 실패했습니다.');
                }
                
                if (data.emails && data.emails.length > 0) {
                    displayEmails(data.emails);
                } else {
                    errorAlert.textContent = '메일이 없습니다.';
                    errorAlert.style.display = 'block';
                }
                
            } catch (error) {
                errorAlert.textContent = error.message;
                errorAlert.style.display = 'block';
            } finally {
                loading.style.display = 'none';
                submitBtn.disabled = false;
            }
        }
        
        function displayEmails(emails) {
            const emailList = document.getElementById('emailList');
            
            let html = '<div class="email-count">📬 받은 메일 (' + emails.length + '개)</div>';
            
            emails.forEach(email => {
                html += \`
                    <div class="email-item">
                        <div class="email-from">보낸사람: \${escapeHtml(email.from || '알 수 없음')}</div>
                        <div class="email-subject">\${escapeHtml(email.subject || '제목 없음')}</div>
                        <div class="email-date">\${escapeHtml(email.date || '')}</div>
                        <div class="email-body">\${escapeHtml(email.body || '본문 없음')}</div>
                    </div>
                \`;
            });
            
            emailList.innerHTML = html;
            emailList.style.display = 'block';
        }
        
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
</body>
</html>
    `);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════╗
║                                               ║
║   📧 네이버 메일 뷰어 서버가 시작되었습니다!   ║
║                                               ║
║   🌐 http://localhost:${PORT}                  ║
║   📝 Environment: ${process.env.NODE_ENV || "development"}           ║
║                                               ║
╚═══════════════════════════════════════════════╝

✅ 준비 완료! 브라우저에서 위 주소로 접속하세요.

⚠️  네이버 메일 IMAP 설정을 먼저 활성화해야 합니다:
    네이버 메일 → 환경설정 → POP3/IMAP 설정 → IMAP/SMTP 사용
    `);
});
